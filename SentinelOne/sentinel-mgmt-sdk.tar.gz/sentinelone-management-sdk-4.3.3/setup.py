from setuptools import setup, find_packages

package_version = '4.3.3'

setup(
    name='sentinelone-management-sdk',
    version=package_version,
    packages=find_packages(exclude=["tests"]),
    license='SentinelOne - Corporate IP', install_requires=['requests', 'six']
)
