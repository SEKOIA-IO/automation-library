@Library(['jenkins-libs@jc', 'auto-dynamic-values@master']) _

timestamps {
    timeout(activity: true, time: 30) {
        k8s.jnlpDinD(
            ADDITIONAL_CONTAINERS: [[
                NAME: 'python-node',
                IMAGE: consoleAutoDynamicVersions.getConsoleAutoLastCleanPythonImageVersion()
            ]]
        ) { label ->
            node(label) {
                try {
                    container("python-node") {
                        ansiColor('xterm') {
                            stage('checkout') {
                                checkout scm
                            }
                            stage("install requirements"){
                                autoCommonUtils.updateRequirements("tests/test_requirements.txt")
                            }
                            autoCommonUtils.preRun()
                            stage('run test') {
                                try {
                                    sshagent(credentials: ['jenkins-key']) {
                                        sh("pytest -vvvv tests \
                                            --junitxml testReport.xml \
                                            --html FunctionalityTestReports/report.html --self-contained-html"
                                        )
                                    }
                                } catch (e) {
                                    autoCommonUtils.setBuildStatusOnFailure(currentBuild)
                                }
                            }
                        }
                    }
                } catch (e) {
                    currentBuild.result = "UNSTABLE"
                    throw e
                } finally {
                    autoCommonUtils.finalizeRun('debugtest')
                }
            }
        }
    }
}
