import json
import logging
from unittest.mock import Mock

import httpretty
import pytest

from management.common.query_filter import QueryFilter
from management.mgmtsdk_v2 import client as client_v2
from management.mgmtsdk_v2 import mgmt as mgmt_v2_0
from management.mgmtsdk_v2.exceptions import InvalidFilterException, InvalidOperatorException
from management.mgmtsdk_v2_1 import mgmt as mgmt_v2_1


class AccountQueryFilter(QueryFilter):
    QUERY_ARGS = {
        'aaa': ['eq'],
        'bbbAt': ['gte', 'lte', 'gt', 'lt', 'between'],
        'ccc': ['eq'],
    }

    def __init__(self):
        super(AccountQueryFilter, self).__init__()


class TestSdk:
    api_client = client_v2

    @pytest.fixture()
    def client_login_mock(self):
        orig_cl = client_v2.Client
        self.api_client.Client = Mock()
        yield
        self.api_client.Client = orig_cl

    @pytest.fixture()
    def mgmt_client_mock(self):
        orig_mgmt_v2_0_client = mgmt_v2_0.Client
        self.mgmt_v2_0 = mgmt_v2_0
        self.mgmt_v2_0.Client = Mock()
        yield
        self.mgmt_v2_0.Client = orig_mgmt_v2_0_client

    def test_init_mgmt_v2_0(self, mgmt_client_mock):
        self.mgmt_v2_0.Client = Mock()
        mgmt_v2_0.Management(hostname="blabla_2_0")

    def test_init_mgmt_v2_1(self, mgmt_client_mock):
        mgmt_v2_1.Client = Mock()
        mgmt_v2_1.Management(hostname="blabla_2_1")

    def test_init_client_with_mock(self, client_login_mock):
        self.api_client.Client("blabla")

    def test_filter_args_wrong_arg(self):
        try:
            AccountQueryFilter.get_query_params(query_filter=None, filter_args=dict(aaab="456", bbbAt__t="789"))
            raise Exception("passed, but expected InvalidFilterException")
        except InvalidFilterException:
            logging.info("InvalidFilterException as expected")

    def test_filter_args_right_arg_wrong_op(self):
        try:
            AccountQueryFilter.get_query_params(query_filter=None, filter_args=dict(aaa="456", bbbAt__t="789"))
            raise Exception("passed, but expected InvalidFilterException")
        except InvalidFilterException:
            logging.info("InvalidFilterException as expected")

    def test_filter_args_right_arg_no_required_op(self):
        try:
            AccountQueryFilter.get_query_params(query_filter=None, filter_args=dict(aaa="456", bbbAt="789"))
            raise Exception("passed, but expected InvalidFilterException")
        except InvalidOperatorException:
            logging.info("InvalidFilterException as expected")

    def test_filter_args_right_args(self):
        params = AccountQueryFilter.get_query_params(query_filter=None, filter_args=dict(aaa="456", bbbAt__gt="789"))
        assert params['aaa'] == "456"
        assert params['bbbAt__gt'] == "789"
        assert 'ccc' not in params

    @httpretty.activate
    def test_init_client_validate_authorization_header(self):
        base_url = "mgmt.sentinelone.com"
        httpretty.register_uri(
            method=httpretty.GET,
            uri=f"https://{base_url}/web/api/v2.0/system/status"
        )

        token = "61d22f8c48077e2678e72b805484d84ad6b96e47c96878e14acbd4687bf0c13234bb0c2e4570535b"
        resp_body = json.dumps({"data": {"token": token}})
        login_url = f"https://{base_url}/web/api/v2.0/users/login"
        pwd = "1234!"
        httpretty.register_uri(
            method=httpretty.POST,
            uri=login_url,
            body=json.dumps({"username": f"admin@{base_url}", "password": pwd}),
            responses=[httpretty.Response(uri=login_url, body=resp_body)])

        client = self.api_client.Client(hostname=f"https://{base_url}",
                                        username=f"admin@{base_url}",
                                        password=pwd)

        assert client.auth_manager.token == token
        assert client.auth_manager.headers.get("Authorization", "") == f"Token {token}"
