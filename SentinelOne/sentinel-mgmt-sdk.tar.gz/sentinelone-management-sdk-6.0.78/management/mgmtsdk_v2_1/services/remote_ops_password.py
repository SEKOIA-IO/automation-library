import http
import logging
from typing import Optional

from management.mgmtsdk_v2.exceptions import raise_from_response

from management.mgmtsdk_v2_1.endpoints import \
    REMOTE_OPS_GENERIC_PASSWORD, REMOTE_OPS_CAN_USE_GENERIC_PASSWORD


class RemoteOpsPassword(object):
    """Remote Ops Password service"""

    def __init__(self, client):
        self.client = client
        self._logger = logging.getLogger('RemoteOpsPassword')

    def create_generic_password_configuration(self, scope_level: str, password: str, scope_id: Optional[int]=None):
        """
        Creates a remote ops password for specific scope

        :param scope_level: scope level of the scope where password is supposed to be configured
        :type scope_level: string "tenant,account,site"
        :param password: password which should be tied to the scope
        :type password: string
        :param scope_id: scope id of the scope where password is supposed to be configured, can be omitted in case of tenant
        scope_level
        :type scope_id: int
        :return: Password configured for the requested scope after the request is handled
        :rtype: Response
        """
        request_data = {
            'password': password,
            'scopeLevel': scope_level,
        }
        if scope_id:
            request_data.update({"scopeId":scope_id})
        res = self.client.post(endpoint=REMOTE_OPS_GENERIC_PASSWORD, data=request_data)
        return res


    def get_generic_password_configuration(self, scope_level: str, scope_id: Optional[int]=None):
        """
        Fetches a remote ops password for specific scope

        :param scope_level: scope level of the scope for which the password is supposed to be fetched
        :type scope_level: string "tenant,account,site"
        :param scope_id: scope id of the scope for which the password is supposed to be fetched, can be omitted in case of tenant
        scope_level
        :type scope_id: int
        :return: Password configured for the requested scope after the request is handled
        :rtype: Response
        """
        params = {
            'scopeLevel': scope_level,
        }
        if scope_id:
            params.update({"scopeId":scope_id})
        res = self.client.get(endpoint=REMOTE_OPS_GENERIC_PASSWORD, params=params)
        return res


    def delete_generic_password_configuration(self, scope_level: str, password: str, scope_id: Optional[int]=None):
        """
        Deletes a remote ops password for specific scope

        :param scope_level: scope level of the scope where password is supposed to be deleted
        :type scope_level: string "tenant,account,site"
        :param password: password which should match the one which is currently tied to the scope
        :type password: string
        :param scope_id: scope id of the scope where password is supposed to be deleted, can be omitted in case of tenant
        scope_level
        :type scope_id: int
        :return: Password configured for the requested scope after the request is handled
        :rtype: Response
        """
        request_data = {
            'password': password,
            'scopeLevel': scope_level,
        }
        if scope_id:
            request_data.update({"scopeId":scope_id})
        res = self.client.delete(endpoint=REMOTE_OPS_GENERIC_PASSWORD, data=request_data)
        return res


    def can_use_generic_password_configuration(self, agent_filter: dict, script_id: Optional[int]=None,
                                               output_destination: Optional[str]=None):
        """
        Determines if and which password can be used when running RSO execution or opening Remote shell session

        :param agent_filter: filter on agents where a desired action (RSO/RS) with password is supposed to be run
        :type agent_filter: dict
        :param script_id: in case of requesting password to use within running RSO, this should contain id of the specific script
        :type script_id: int
        :param output_destination: in case of requesting password to use within running RSO, this should contain the
        output destination of the execution results
        :type output_destination: str "SentinelCloud,Local,None,SingularityXDR"
        :return: if running action RSO/RS can be performed with password and from which scope
        :rtype: Response
        """
        data = dict()
        if script_id:
            data.update({"scriptId":script_id})
        if output_destination:
            data.update({"outputDestination":output_destination})

        if len(data)>0:
            res = self.client.post(endpoint=REMOTE_OPS_CAN_USE_GENERIC_PASSWORD, data=data, query_filter=agent_filter)
        else:
            res = self.client.post(endpoint=REMOTE_OPS_CAN_USE_GENERIC_PASSWORD, query_filter=agent_filter)
        return res


