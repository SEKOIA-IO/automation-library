import logging

from management.common.query_filter import QueryFilter
from management.mgmtsdk_v2_1.endpoints import *
from management.mgmtsdk_v2_1.entities.service_user import ServiceUser
from management.mgmtsdk_v2.exceptions import raise_from_response

logger = logging.getLogger('ServiceUser')


class ServiceUserQueryFilter(QueryFilter):
    QUERY_ARGS = {
        'ids': ['eq'],
        'accountIds': ['eq'],
        'siteIds': ['eq'],
        'roleIds': ['eq'],
        'query': ['eq'],
        'limit': ['eq'],
        'sortBy': ['eq'],
        'sortOrder': ['eq'],
    }

    def __init__(self):
        super(ServiceUserQueryFilter, self).__init__()


class ServiceUsers(object):
    """ServiceUsers service"""

    def __init__(self, client):
        self.client = client

    def get(self, query_filter=None, **user_args):
        """
        :param query_filter: Query filter object
        :type query_filter: UserQueryFilter
        :param user_args: Key value with query filters
        :type user_args: **dict
        :return: Users answering the query
        :rtype: ManagementResponse
        """
        query_params = ServiceUserQueryFilter.get_query_params(query_filter, user_args)
        ret = []
        res = self.client.get(endpoint=GET_SERVICE_USERS, params=query_params)
        if res.status_code != 200:
            logger.warning("Failed to get service users, response_code: {}".format(res.json))
            raise_from_response(res)
        service_users = res.data
        for service_user in service_users:
            ret.append(ServiceUser(**service_user))
        res.data = ret
        return res

    def create(self, **kwargs):
        """
        :params name, desc, exp_date, scope, scope_roles
        :return: created user
        :rtype: ManagementResponse
        """
        data = dict()
        for item in kwargs.keys():
            data[item] = kwargs.get(item, None)

        res = self.client.post(endpoint=CREATE_SERVICE_USER, data=data)
        if res.status_code != 200:
            logger.warning("Failed to create service user, response_code: {}".format(res.json))
            raise_from_response(res)
        res.data = ServiceUser(**res.data)
        return res

    def update(self, service_user_id, **kwargs):
        """
        :param service_user_id:
        :type service_user_id: string
        :return: updated user
        :rtype: ManagementResponse
        """
        res = self.client.put(endpoint=UPDATE_SERVICE_USER.format(service_user_id), data=kwargs)
        if res.status_code != 200:
            logger.warning("Failed to update service user, response_code: {}".format(res.json))
            raise_from_response(res)
        res.data = ServiceUser(**res.data)
        return res

    def delete(self, service_user_id):
        """
        :param service_user_id:
        :type service_user_id: string
        :return: success status
        :rtype: ManagementResponse
        """
        res = self.client.delete(endpoint=DELETE_SERVICE_USER.format(service_user_id), data={})
        if res.status_code != 200:
            logger.warning("Failed to delete service user, response_code: {}".format(res.json))
            raise_from_response(res)
        res.data = res.data['success']
        return res

    def delete_users(self, query_filter=None, **user_args):
        """
        :param query_filter: Query filter object
        :type query_filter: UserQueryFilter
        :param user_args: Key value with query filters
        :type user_args: **dict
        :return: success status
        :rtype: ManagementResponse
        """
        query_params = ServiceUserQueryFilter.get_query_params(query_filter, user_args)
        res = self.client.post(endpoint=DELETE_SERVICE_USERS, data={}, query_filter=query_params)
        if res.status_code != 200:
            logger.warning("Failed to delete service users, response_code: {}".format(res.json))
            raise_from_response(res)
        res.data = int(res.data['affected'])
        return res
