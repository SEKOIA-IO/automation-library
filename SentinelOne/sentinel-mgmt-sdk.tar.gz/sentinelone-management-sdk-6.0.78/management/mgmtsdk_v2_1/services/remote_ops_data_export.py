import logging
from typing import Dict, Any, List, Optional

from management.mgmtsdk_v2.client import ManagementResponse
from management.mgmtsdk_v2.exceptions import raise_from_response
from management.mgmtsdk_v2_1.endpoints import REMOTE_OPS_DATA_EXPORT_DESTINATION_PROFILES,\
    REMOTE_OPS_DATA_EXPORT_SET_DEFAULT, REMOTE_OPS_DATA_EXPORT_GET_TASK_RESULT
from management.mgmtsdk_v2_1.entities.remote_ops_data_export import DestinationProfile


class RemoteOpsDataExport(object):
    """Remote Ops Data Export service"""
    def __init__(self, client):
        self.client = client
        self._logger = logging.getLogger('RemoteOpsDataExport')

    def add_destination_profile(self, destination_profile: Dict[str, Any]) -> ManagementResponse:
        """
        Add destination profile
        :param destination_profile:
        :rtype: ManagementResponse
        """
        res = self.client.post(endpoint=REMOTE_OPS_DATA_EXPORT_DESTINATION_PROFILES, payload=destination_profile)

        if res.status_code != 200:
            self._logger.warning(f"Failed to create destination profile, response_code: {res.status_code}")
            raise_from_response(res)
        return res

    def get_destination_profiles(self, scope_level: str, scope_id: str) -> ManagementResponse:
        """
        Add destination profile
        :param scope_level:
        :param scope_id:
        :rtype: ManagementResponse
        """
        res = self.client.get(endpoint=REMOTE_OPS_DATA_EXPORT_DESTINATION_PROFILES, params={
            'scopeId': scope_id,
            'scopeLevel': scope_level,
        })

        if res.status_code != 200:
            self._logger.warning(f"Failed to get destination profiles, response_code: {res.status_code}")
            raise_from_response(res)

        res.data = [DestinationProfile(**profile) for profile in res.data]
        return res

    def update_destination_profiles(self, profile_id: str, destination_profile: Dict[str, Any]) -> ManagementResponse:
        """
        Update destination profile
        :param profile_id:
        :param destination_profile:
        :rtype: ManagementResponse
        """
        res = self.client.put(endpoint=f'{REMOTE_OPS_DATA_EXPORT_DESTINATION_PROFILES}/{profile_id}',
                              payload=destination_profile)

        if res.status_code != 200:
            self._logger.warning(f"Failed to update destination profiles, response_code: {res.status_code}")
            raise_from_response(res)
        return res

    def delete_destination_profile(self, profile_id: str) -> None:
        """
        delete destination profile by id
        :param profile_id:
        """
        res = self.client.delete(endpoint=f'{REMOTE_OPS_DATA_EXPORT_DESTINATION_PROFILES}/{profile_id}')

        if res.status_code != 200:
            self._logger.warning(f"Failed to delete destination profile, response_code: {res.status_code}")
            raise_from_response(res)

    def delete_destination_profiles(self, profile_ids: List[str]) -> ManagementResponse:
        """
        delete destination profiles by id
        :param profile_ids:
        :rtype: ManagementResponse
        """
        res = self.client.delete(endpoint=REMOTE_OPS_DATA_EXPORT_DESTINATION_PROFILES, query_filter={'ids': profile_ids})

        if res.status_code != 200:
            self._logger.warning(f"Failed to delete destination profiles, response_code: {res.status_code}")
            raise_from_response(res)
        return res

    def set_destination_profile_as_default(self, profile_id: str, scope_level: str, scope_id: str) -> None:
        """
        Set destination profile as default in specific scope
        :param profile_id:
        :param scope_level:
        :param scope_id:
        """
        res = self.client.post(endpoint=REMOTE_OPS_DATA_EXPORT_SET_DEFAULT, data={
            'scopeLevel': scope_level,
            'scopeId': scope_id,
            'profileId': profile_id
        })

        if res.status_code != 200:
            self._logger.warning(f"Failed to set destination profile as default, response_code: {res.status_code}")
            raise_from_response(res)

    def get_task_result(self, agent_id: str, task_id: Optional[str] = None, malicious_group_id: Optional[str] = None) \
            -> ManagementResponse:
        """
        Get data exporter upload task results by agent_id and task_id or malicious_group_id
        :param agent_id:
        :param task_id:
        :param malicious_group_id:
        :rtype: ManagementResponse
        """
        params = {
            'agentId': agent_id
        }
        if task_id:
            params['taskId'] = task_id
        if malicious_group_id:
            params['maliciousGroupId'] = malicious_group_id

        res = self.client.get(endpoint=REMOTE_OPS_DATA_EXPORT_GET_TASK_RESULT, params=params)

        if res.status_code != 200:
            self._logger.warning(f"Failed to fetch data exporter results by params, {params}"
                                 f"response_code: {res.status_code}")
            raise_from_response(res)
        return res
