import http.client
import os
import logging
from contextlib import ExitStack
from typing import List, Optional

from six.moves import http_client as httplib

from management.common.query_filter import QueryFilter
from management.mgmtsdk_v2.client import ManagementResponse
from management.mgmtsdk_v2.entities.task import Task
from management.mgmtsdk_v2.services.task import TaskQueryFilter
from management.mgmtsdk_v2_1.endpoints import *
from management.mgmtsdk_v2.exceptions import raise_from_response
from management.mgmtsdk_v2_1.entities.remote_script import RemoteScript, RemoteScriptsDownloadLink, \
    RemoteScriptsDownloadLinkError, RemoteScriptContent

logger = logging.getLogger('RemoteScripts')


class RemoteScriptsQueryFilter(QueryFilter):
    QUERY_ARGS = {
        'ids': ['eq'],
        'osTypes': ['eq'],
        'scriptType': ['eq'],
        'threatContentHash': ['eq'],
        'tenant': ['eq'],
        'accountIds': ['eq'],
        'siteIds': ['eq'],
        'groupIds': ['eq'],
        'query': ['eq'],
        'limit': ['eq'],
        'cursor': ['eq'],
        'skip': ['eq'],
        'skipCount': ['eq'],
        'sortBy': ['eq'],
        'sortOrder': ['eq'],
    }

    def __init__(self):
        super(RemoteScriptsQueryFilter, self).__init__()


class PendingExecutionsQueryFilter(QueryFilter):
    QUERY_ARGS = {
        'tenant': ['eq'],
        'accountIds': ['eq'],
        'siteIds': ['eq'],
        'groupIds': ['eq'],
        'limit': ['eq'],
        'cursor': ['eq'],
        'skip': ['eq'],
        'skipCount': ['eq'],
        'sortBy': ['eq'],
        'sortOrder': ['eq'],
    }


class RemoteScripts(object):
    """Remote Scripts Orchestration service"""

    def __init__(self, client):
        self.client = client

    # Remote scripts
    def get(self, query_filter=None, **script_args):
        """
        Get list of ``scripts`` from the console by filters, default filter is empty

        :type query_filter: RemoteScriptsQueryFilter
        :type script_args: dict
        :rtype: ManagementResponse
        """
        query_params = RemoteScriptsQueryFilter.get_query_params(query_filter, script_args)
        res = self.client.get(endpoint=REMOTE_SCRIPTS_GET_SCRIPTS, params=query_params)
        if res.status_code != 200:
            logger.warning(f"Failed to get remote scripts, response_code: {res.status_code}")
            raise_from_response(res)
        res.data = [RemoteScript(**script) for script in res.data]
        return res

    def add(self, script):
        """
        add remote script
        :param script:
        :rtype: ManagementResponse
        """

        files = dict()
        file_path = script.pop("filePath", "script_test.txt")
        if not os.path.exists(file_path):
            if file_path == 'script_test.txt':
                file = open(file_path, "w")
                file.write("#!/bin/bash")
                file.close()
            else:
                raise FileNotFoundError(f'File {file_path} not found')

        package_path = script.pop("packagePath", None)
        if package_path and not os.path.exists(package_path):
            raise FileNotFoundError(f'File {package_path} not found')

        for key in script:
            files[key] = (None, script[key])

        with ExitStack() as files_context:
            script_fh = files_context.enter_context(open(file_path, 'rb'))
            files['file'] = (os.path.basename(file_path), script_fh, 'application/terminal')
            if package_path:
                package_fh = files_context.enter_context(open(package_path, 'rb'))
                files['packageFile'] = (os.path.basename(package_path), package_fh, 'application/terminal')

            res = self.client.post(endpoint=REMOTE_SCRIPTS_ADD_SCRIPT, files=files)

        if res.status_code != 200:
            logger.warning(f"Failed to add remote script, response_code: {res.status_code}")
            raise_from_response(res)
        res.data = RemoteScript(**res.data)
        return res.data

    def execute(self, script, query_filter=None, **script_args):
        """
        Execute remote script
        :param script:
        :param query_filter:
        :param script_args:
        :rtype: ManagementResponse
        """
        query_params = RemoteScriptsQueryFilter.get_query_params(query_filter, script_args)
        res = self.client.post(endpoint=REMOTE_SCRIPTS_EXECUTE_SCRIPT, query_filter=query_params, data=script)
        if res.status_code != 200:
            logger.warning(f"Failed to execute remote script, response_code: {res.status_code}")
            raise_from_response(res)
        parsed_data = {
            "affected": int(res.data.get('affected', 0)),
            "parentTaskId": res.data.get('parentTaskId', ''),
        }
        if res.data.get('pending'):
            parsed_data.update({
                "pending": res.data.get('pending', None),
                "pendingExecutionId": res.data.get('pendingExecutionId', None),
            })
        res.data = parsed_data
        return res

    def edit(self, script_id, script_name, script_type, os_types, input_example, input_instructions,
             input_required, script_run_timeout, script_description=None, package_endpoint_expiration=None,
             package_endpoint_expiration_seconds=None):
        """
        Edit remote script
        :param script_id:
        :param script_name:
        :param script_type:
        :param os_types:
        :param input_example:
        :param input_instructions:
        :param input_required:
        :param script_run_timeout:
        :param script_description:
        :param package_endpoint_expiration:
        :param package_endpoint_expiration_seconds:
        :rtype: ManagementResponse
        """

        new_data = {
            'scriptName': script_name,
            'scriptType': script_type,
            'osTypes': os_types,
            'inputExample': input_example,
            'inputInstructions': input_instructions,
            'inputRequired': input_required,
            'scriptRuntimeTimeoutSeconds': script_run_timeout
        }
        if script_description is not None:
            new_data['scriptDescription'] = script_description
        if package_endpoint_expiration is not None:
            new_data['packageEndpointExpiration'] = package_endpoint_expiration
        if package_endpoint_expiration_seconds is not None:
            new_data['packageEndpointExpirationSeconds'] = package_endpoint_expiration_seconds

        res = self.client.put(endpoint=REMOTE_SCRIPTS_EDIT_SCRIPT.format(script_id), data=new_data)
        if res.status_code != 200:
            logger.warning(f"Failed to edit remote script, response_code: {res.status_code}")
            raise_from_response(res)
        res.data = [RemoteScript(**script) for script in res.data]
        return res

    def edit_v2(
            self,
            script_id: int,
            script_name: str,
            script_type: str,
            os_types: str,
            input_example: str,
            input_instructions: str,
            input_required: bool, script_run_timeout: int,
            script_description: Optional[str]=None,
            package_endpoint_expiration: Optional[str]=None,
            package_endpoint_expiration_seconds: Optional[int]=None,
            new_script_path: Optional[str] = None,
            new_package_path: Optional[str] = None,
            package_removed: Optional[bool] = None,
            explicit_script_content: Optional[str] = None,
            is_script_content_encoded: Optional[bool] = False) -> ManagementResponse:
        """
        Edit remote script
        :param script_id: script id of script that is supposed to be edited, goes then into the URL
        :param script_name: new name of script
        :param script_type: new type of script
        :param os_types: comma separated values of os types - possibility of choice among 3 os types -
                            windows, linux and macos - example value: 'windows,macos'
        :param input_example: new input example
        :param input_instructions: new input instructions
        :param input_required: new input_required field
        :param script_run_timeout: new timeout
        :param script_description: new description
        :param package_endpoint_expiration: new package endpoint expiration, should be one of possible acceptable values  - optional
        :param package_endpoint_expiration_seconds: new package endpoint expiration time in seconds - optional
        :param new_script_path: optional path of a new script file which replaces the old one, has precedence over explicit_script_content
        :param new_package_path: optional path of a new package file which replaces the old one or creates it if none exists,
                                has precedence over package_removed
        :param package_removed: if True set, removes the package (if it exists)
        :param explicit_script_content: changes the script content
        :param is_script_content_encoded: mark as True if the script content is encoded in base64, used by UI to prevent
                browsers from replacing LF for CRLF in script content
        :rtype: ManagementResponse
        """
        new_data = {
            'scriptName': script_name,
            'scriptType': script_type,
            'osTypes': os_types,
            'inputExample': input_example,
            'inputInstructions': input_instructions,
            'inputRequired': input_required,
            'scriptRuntimeTimeoutSeconds': script_run_timeout
        }

        if script_description is not None:
            new_data['scriptDescription'] = script_description
        if package_endpoint_expiration is not None:
            new_data['packageEndpointExpiration'] = package_endpoint_expiration
        if package_endpoint_expiration_seconds is not None:
            new_data['packageEndpointExpirationSeconds'] = package_endpoint_expiration_seconds
        if package_removed:
            new_data['packageRemoved'] = True
        if explicit_script_content is not None:
            new_data['scriptContent'] = explicit_script_content
        if is_script_content_encoded:
            new_data['isScriptContentEncoded'] = True

        files = dict()
        for script_field, script_field_value in new_data.items():
            files[script_field] = (None, script_field_value)

        if new_script_path is not None:
            if not os.path.exists(new_script_path): raise FileNotFoundError(f'File {new_script_path} not found')
        if new_package_path is not None:
            if not os.path.exists(new_package_path): raise FileNotFoundError(f'File {new_package_path} not found')

        with ExitStack() as files_context:
            if new_script_path is not None:
                script_file = files_context.enter_context(open(new_script_path, 'rb'))
                files['scriptFile'] = (os.path.basename(new_script_path), script_file, 'application/terminal')
            if new_package_path is not None:
                package_file = files_context.enter_context(open(new_package_path, 'rb'))
                files['packageFile'] = (os.path.basename(new_package_path), package_file, 'application/terminal')

            res = self.client.put(endpoint=REMOTE_SCRIPTS_EDIT_V2_SCRIPT.format(script_id), files=files)

        if res.status_code != 200:
            logger.warning(f"Failed to edit remote script, response_code: {res.status_code}")
            raise_from_response(res)
        res.data = RemoteScript(**res.data)
        return res

    def delete(self, query_filter=None, **script_args):
        """
        Delete remote script
        :param query_filter:
        :param script_args:
        :rtype: ManagementResponse
        """
        query_params = RemoteScriptsQueryFilter.get_query_params(query_filter, script_args)
        res = self.client.delete(endpoint=REMOTE_SCRIPTS_DELETE_SCRIPT, query_filter=query_params, data={})
        if res.status_code != 200:
            logger.warning(f"Failed to delete remote script, response_code: {res.status_code}")
            raise_from_response(res)
        res.data = int(res.data['affected'])
        return res

    def status(self, query_filter=None, **task_args):
        """
        Get list of RSO ``Tasks`` from the console by filters, default filter is empty

        :type query_filter: TaskQueryFilter
        :type task_args: dict
        :rtype: ManagementResponse
        """
        query_params = TaskQueryFilter.get_query_params(query_filter, task_args)
        res = self.client.get(endpoint=REMOTE_SCRIPTS_STATUS, params=query_params)
        if res.status_code != 200:
            logger.warning("Failed to get remote scripts tasks, response_code: {}".format(res.status_code))
            raise_from_response(res)
        res.data = [Task(**task) for task in res.data]
        return res

    def fetch_files(self, task_ids: [str] = None, computer_names: [str] = None):
        """
        Get a list of download links based on a list of task id's or computer names filter
        Can be only one or the other (task ids or computer name)

        :type: task_ids: array[str]
        :type: computer_names: array[str]
        :rtype: ManagementResponse
        """

        task_ids_computer_names_object = dict()
        if task_ids is not None:
            task_ids_computer_names_object['taskIds'] = task_ids
        if computer_names is not None:
            task_ids_computer_names_object['computerNames'] = computer_names

        res = self.client.post(endpoint=REMOTE_SCRIPTS_FETCH_FILES, data=task_ids_computer_names_object)
        if res.status_code != 200:
            logger.warning("Failed to fetch download links. response_code: {}".format(res.status_code))
            raise_from_response(res)
        res.data = {
                        'download_links': [RemoteScriptsDownloadLink(**link) for link in res.data['download_links']],
                        'errors': [RemoteScriptsDownloadLinkError(**err) for err in res.data['errors']]
                   }
        return res

    def get_contents(self, script_id: str):
        """
        Get text contents of remote script file.
        :param: script_id: str
        :rtype: ManagementResponse
        """
        params = {'scriptId': script_id}
        res = self.client.get(endpoint=REMOTE_SCRIPTS_SCRIPT_CONTENT, params=params)
        if res.status_code == http.client.BAD_REQUEST and 'error' in res.json:
            res.data = RemoteScriptContent(script_id, content=None, reason=res.json['error'])
        elif res.status_code != httplib.OK:
            logger.warning("Failed to get contents of remote script. response_code: {}".format(res.status_code))
            raise_from_response(res)
        else:
            res.data = RemoteScriptContent(script_id, content=res.json['data']['scriptContent'])
        return res

    def get_guardrails_configuration(self, scope_id: str, scope_level: str):
        """
        Get guardrails configuration of specific scope.
        :param scope_id: str
        :param scope_level: str
        :rtype: ManagementResponse
        """
        params = {'scopeId': str(scope_id), 'scopeLevel': scope_level}
        res = self.client.get(endpoint=REMOTE_SCRIPTS_GUARDRAILS_CONFIGURATION, params=params)
        if res.status_code != httplib.OK:
            logger.warning("Failed to get guardrails configuration. response_code: {}".format(res.status_code))
            raise_from_response(res)
        return res

    def delete_guardrails_configuration(self, scope_id: str, scope_level: str):
        """
        Delete guardrails configuration of specific scope.
        :param scope_id: str
        :param scope_level: str
        :rtype: ManagementResponse
        """
        req_data = {'scopeId': str(scope_id), 'scopeLevel': scope_level}
        res = self.client.delete(endpoint=REMOTE_SCRIPTS_GUARDRAILS_CONFIGURATION, data=req_data)
        if res.status_code != httplib.OK:
            logger.warning("Failed to remove guardrails configuration. response_code: {}".format(res.status_code))
            raise_from_response(res)
        return res

    def set_guardrails_configuration(self, scope_id: str, scope_level: str, enabled: bool, script_types: List[str],
                                     endpoints_quantity: int):
        """
        Set guardrails configuration parameters of specific scope.
        :param scope_id: str
        :param scope_level: str
        :param enabled: bool
        :param script_types: List[str]
        :param endpoints_quantity: int
        :rtype: ManagementResponse
        """
        req_data = {
            'scopeId': str(scope_id),
            'scopeLevel': scope_level,
            'enabled': enabled,
            'scriptTypes': script_types,
            'endpointsQuantity': endpoints_quantity,
        }
        res = self.client.post(endpoint=REMOTE_SCRIPTS_GUARDRAILS_CONFIGURATION, data=req_data)
        if res.status_code != httplib.OK:
            logger.warning("Failed to set guardrails configuration. response_code: {}".format(res.status_code))
            raise_from_response(res)
        return res

    def get_pending_executions(self, query_filter: Optional[PendingExecutionsQueryFilter] = None, **filter_args):
        """
        Get pending executions according to the filter.
        :param query_filter: Optional[PendingExecutionsQueryFilter]
        :param filter_args: dict
        :rtype: ManagementResponse
        """
        query_params = PendingExecutionsQueryFilter.get_query_params(query_filter, filter_args)
        res = self.client.get(endpoint=REMOTE_SCRIPTS_PENDING_EXECUTIONS, params=query_params)
        if res.status_code != httplib.OK:
            logger.warning("Failed to get pending executions. response_code: {}".format(res.status_code))
            raise_from_response(res)
        return res

    def _review_pending_execution(self, pending_execution_id: str, action: str):
        """
        Approve/decline pending execution according to action param.
        :param pending_execution_id: str
        :param action: str
        :rtype: ManagementResponse
        """
        req_data = {"action": action}
        res = self.client.put(endpoint=REMOTE_SCRIPTS_REVIEW_PENDING_EXECUTIONS.format(pending_execution_id),
                              data=req_data)
        print(res.response.request.headers)
        if res.status_code != httplib.OK:
            logger.warning("Failed to {} pending executions. response_code: {}".format(action, res.status_code))
            raise_from_response(res)
        return res

    def approve_pending_execution(self, pending_execution_id: str):
        """
        Approve pending execution.
        :param pending_execution_id: str
        :rtype: ManagementResponse
        """
        return self._review_pending_execution(pending_execution_id, 'approve')

    def decline_pending_execution(self, pending_execution_id: str):
        """
        Decline pending execution.
        :param pending_execution_id: str
        :rtype: ManagementResponse
        """
        return self._review_pending_execution(pending_execution_id, 'decline')
