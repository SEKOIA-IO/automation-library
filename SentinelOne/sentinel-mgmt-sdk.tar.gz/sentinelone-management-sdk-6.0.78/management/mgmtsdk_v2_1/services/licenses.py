import logging

from management.common.query_filter import QueryFilter
from management.mgmtsdk_v2.endpoints import SET_TENANT_LICENSES
from management.mgmtsdk_v2_1.endpoints import *
from management.mgmtsdk_v2.exceptions import raise_from_response

logger = logging.getLogger('Licenses')


class LicensesQueryFilter(QueryFilter):

    QUERY_ARGS = {
        'bundles': ['eq'],
        'modules': ['eq'],
    }

    def __init__(self):
        super(LicensesQueryFilter, self).__init__()


class Licenses(object):
    """Licenses service"""

    def __init__(self, client):
        self.client = client

    def get_available_bundles(self):
        """
        :return: Available Bundles in tenant
        :rtype: ManagementResponse
        """
        res = self.client.get(endpoint=GET_AVAILABLE_BUNDLES)
        logger.info('payload of get_available_bundles is {}'.format(res.response.request.body))
        if res.status_code != 200:
            logger.warning("Failed to get available bundles, response_code: {}".format(res.json))
            raise_from_response(res)
        return res

    def get_available_modules(self, bundles):
        """
        :param bundles: Bundles
        :type bundles: String "core,control"
        :return: Available Modules in tenant
        :rtype: ManagementResponse
        """

        res = self.client.get(endpoint=GET_AVAILABLE_MODULES, data={'bundles': bundles})
        logger.info('payload of get_available_modules is {}'.format(res.response.request.body))
        if res.status_code != 200:
            logger.warning("Failed to get modules, response_code: {}".format(res.json))
            raise_from_response(res)
        return res

    def get_available_license_settings(self, bundles, modules=None):
        """
        :param bundles: Bundles
        :type bundles: String "core,control"
        :param modules: Modules
        :type bundles: String "ranger,dv"
        :return: Available settings of the requested Modules in tenant
        :rtype: ManagementResponse
        """

        res = self.client.get(endpoint=GET_AVAILABLE_LICENSE_SETTINGS, data={'bundles': bundles, 'modules': modules})
        logger.info('payload of get_available_license_settings is {}'.format(res.response.request.body))
        if res.status_code != 200:
            logger.warning("Failed to get license settings, response_code: {}".format(res.json))
            raise_from_response(res)
        return res

    def set_tenant_licenses(self, bundles=None, modules=None, settings=None):
        """
                :param bundles: Bundles
                :type bundles: String "core,control"
                :param modules: Modules
                :type modules: String "ranger,dv"
                :param settings: Modules
                :type settings: String "ranger,dv"
                :return: Available settings of the requested Modules in tenant
                :rtype: ManagementResponse
                """

        # query_params = LicensesQueryFilter.get_query_params(query_filter, None)
        new_data = {
            'licenses': {
                'bundles': bundles,
                'modules': modules,
                'settings': settings
            }
        }
        res = self.client.put(endpoint=SET_TENANT_LICENSES, data=new_data)
        logger.info('payload of get_available_modules is {}'.format(res.response.request.body))
        if res.status_code != 200:
            logger.warning("Failed to get modules, response_code: {}".format(res.json))
            raise_from_response(res)
        return res