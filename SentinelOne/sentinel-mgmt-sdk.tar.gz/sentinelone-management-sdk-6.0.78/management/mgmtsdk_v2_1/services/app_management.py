import logging

from management.common.query_filter import BaseScopeFilter
from management.mgmtsdk_v2.exceptions import raise_from_response
from management.mgmtsdk_v2_1.endpoints import *
from management.mgmtsdk_v2_1.entities.app_management import get_risk_data_class


class AppManagement(object):
    """ Application management service """
    def __init__(self, client):
        self.client = client

    def init_scan(self, scope_filter=None, **scope_args):
        """
        :param scope_filter: Scope filter object
        :type scope_filter: FullScopeFilter
        :param scope_args: Key value with query filters
        :type scope_args: **dict
        :return: affected number
        :rtype: ManagementResponse
        """
        query_params = BaseScopeFilter.get_query_params(scope_filter, scope_args)
        res = self.client.post(endpoint=APP_SCAN, query_filter=query_params)
        if res.status_code != 200:
            logging.info(f"Failed to init app management scan, response code: {res.status_code} json: {res.json}")
            raise_from_response(res)
        return res

    def get_scan_status(self, scope_filter=None, **scope_args):
        """
        :param scope_filter: Scope filter object
        :type scope_filter: FullScopeFilter
        :param scope_args: Key value with query filters
        :type scope_args: **dict
        :return: risks scan status dict
        :rtype: ManagementResponse
        """
        query_params = BaseScopeFilter.get_query_params(scope_filter, scope_args)
        res = self.client.get(endpoint=APP_SCAN_STATUS, params=query_params)
        if res.status_code != 200:
            logging.info(f"Failed to get app management scan status, response code: {res.status_code} json: {res.json}")
            raise_from_response(res)
        return res

    def get_settings(self, scope_filter=None, **scope_args):
        """ Returns the app management settings for the given scope (global if None) """
        query_params = BaseScopeFilter.get_query_params(scope_filter, scope_args)
        res = self.client.get(endpoint=APP_SETTINGS, params=query_params)
        if res.status_code != 200:
            logging.info(f"Failed to get app management settings, response code: {res.status_code} json: {res.json}")
            raise_from_response(res)
        return res

    def update_settings(self, query_filter=None, **kwargs):
        """ Updates the app management settings """
        res = self.client.post(endpoint=APP_SETTINGS, query_filter=query_filter, data=kwargs)
        if res.status_code != 200:
            logging.info(f"Failed to update app management settings, response code: {res.status_code} json: {res.json}")
            raise_from_response(res)
        return res

    def get_risks(self, **params):
        res = self.client.get(endpoint=RISKS_GET, params=params)
        if res.status_code != 200:
            logging.info(f"Failed to get risks, response code: {res.status_code} json: {res.json}")
            raise_from_response(res)
        return res

    def get_risks_expanded(self, risk_id: str, scope_filter=None, **scope_args):
        """
        :param risk_id: risk id to expand
        :param scope_filter: Scope filter object
        :type scope_filter: FullScopeFilter
        :param scope_args: Key value with query filters
        :type scope_args: **dict
        :return: risks scan status dict
        :rtype: ManagementResponse
        """
        query_params = BaseScopeFilter.get_query_params(scope_filter, scope_args)
        res = self.client.get(endpoint=RISKS_EXPANDED.format(risk_id), params=query_params)
        if res.status_code != 200:
            logging.info(f"Failed to get risks expanded for {risk_id}, response code: {res.status_code} json: {res.json}")
            raise_from_response(res)
        if res.data:
            res.data = {data_type: get_risk_data_class(data_type=data_type, **data)
                        for data_type, data in res.data.items()}
        return res

    def get_risks_filter_count(self, **params):
        res = self.client.get(endpoint=RISKS_FILTERS_COUNT, params=params)
        if res.status_code != 200:
            logging.info(f"Failed to get risks filters count, response code: {res.status_code} json: {res.json}")
            raise_from_response(res)
        return res

    def export_risks(self, **params):
        res = self.client.get(endpoint=RISKS_EXPORT, params=params)
        if res.status_code != 200:
            logging.info(f"Failed to export risks, response code: {res.status_code} json: {res.json}")
            raise_from_response(res)
        return res

    def get_inventory(self, **params):
        res = self.client.get(endpoint=INVENTORY_GET, params=params)
        if res.status_code != 200:
            logging.info(f"Failed to get inventory, response code: {res.status_code} json: {res.json}")
            raise_from_response(res)
        return res

    def get_inventory_filter_count(self, **params):
        res = self.client.get(endpoint=INVENTORY_FILTERS_COUNT, params=params)
        if res.status_code != 200:
            logging.info(f"Failed to get inventory filters count, response code: {res.status_code} json: {res.json}")
            raise_from_response(res)
        return res

    def export_inventory(self, **params):
        res = self.client.get(endpoint=INVENTORY_EXPORT, params=params)
        if res.status_code != 200:
            logging.info(f"Failed to export inventory, response code: {res.status_code} json: {res.json}")
            raise_from_response(res)
        return res

    def get_inventory_versions_count(self, app_name, app_vendor, scope_filter=None, **scope_args):
        query_params = BaseScopeFilter.get_query_params(scope_filter, scope_args)
        query_params.update({'applicationName': app_name, 'applicationVendor': app_vendor})
        res = self.client.get(endpoint=INVENTORY_VERSIONS_COUNT, params=query_params)
        if res.status_code != 200:
            logging.info(f"Failed to get inventory versions count, response code: {res.status_code} json: {res.json}")
            raise_from_response(res)
        return res

    def get_inventory_endpoints(self, app_name, app_vendor, **params):
        params.update({'applicationName': app_name, 'applicationVendor': app_vendor})
        res = self.client.get(endpoint=INVENTORY_ENDPOINTS, params=params)
        if res.status_code != 200:
            logging.info(f"Failed to get inventory endpoints, response code: {res.status_code} json: {res.json}")
            raise_from_response(res)
        return res

    def get_risks_aggregated_apps(self, **params):
        res = self.client.get(endpoint=RISKS_AGGREGATED_APPS, params=params)
        if res.status_code != 200:
            logging.info(f"Failed to get risks aggregated by apps, response code: {res.status_code} json: {res.json}")
            raise_from_response(res)
        return res

    def get_risks_aggregated_impactful_apps(self, **params):
        res = self.client.get(endpoint=RISKS_AGGREGATED_IMPACTFUL_APPS, params=params)
        if res.status_code != 200:
            logging.info(f"Failed to get risks aggregated impactful apps, response code: {res.status_code} json: {res.json}")
            raise_from_response(res)
        return res

    def get_risks_impactful_apps(self, **params):
        res = self.client.get(endpoint=RISKS_IMPACTFUL_APPS, params=params)
        if res.status_code != 200:
            logging.info(f"Failed to get risk impactful apps, response code: {res.status_code} json: {res.json}")
            raise_from_response(res)
        return res

    def get_risks_apps(self, **params):
        res = self.client.get(endpoint=RISKS_APPS, params=params)
        if res.status_code != 200:
            logging.info(f"Failed to get risk apps, response code: {res.status_code} json: {res.json}")
            raise_from_response(res)
        return res

    def get_risks_endpoints(self, **params):
        res = self.client.get(endpoint=RISKS_ENDPOINTS, params=params)
        if res.status_code != 200:
            logging.info(f"Failed to get risk endpoints, response code: {res.status_code} json: {res.json}")
            raise_from_response(res)
        return res

    def get_risks_cves(self, **params):
        res = self.client.get(endpoint=RISKS_CVES, params=params)
        if res.status_code != 200:
            logging.info(f"Failed to get risk cves, response code: {res.status_code} json: {res.json}")
            raise_from_response(res)
        return res

    def get_risks_app_summary(self, **params):
        res = self.client.get(endpoint=RISKS_APP_SUMMARY, params=params)
        if res.status_code != 200:
            logging.info(f"Failed to get risk apps summary, response code: {res.status_code} json: {res.json}")
            raise_from_response(res)
        return res

    def get_risks_cve_detail(self, cve_id, **params):
        res = self.client.get(endpoint=RISKS_CVE_DETAIL.format(cve_id), params=params)
        if res.status_code != 200:
            logging.info(f"Failed to get risk cve detail, response code: {res.status_code} json: {res.json}")
            raise_from_response(res)
        return res

    def get_risks_aggregated_apps_export(self, **params):
        res = self.client.get(endpoint=RISKS_AGGREGATED_APPS_EXPORT, params=params)
        if res.status_code != 200:
            logging.info(f"Failed to export risk aggregated apps, response code: {res.status_code} json: {res.json}")
            raise_from_response(res)
        return res

    def get_risks_aggregated_apps_filters_count(self, **params):
        res = self.client.get(endpoint=RISKS_AGGREGATED_APPS_FILTERS_COUNT, params=params)
        if res.status_code != 200:
            logging.info(f"Failed to get risks aggregated apps filter count, response code: {res.status_code} json: {res.json}")
            raise_from_response(res)
        return res

    def get_risks_aggregated_apps_free_text_filters(self, **params):
        res = self.client.get(endpoint=RISKS_AGGREGATED_APPS_FREE_TEXT_FILTERS, params=params)
        if res.status_code != 200:
            logging.info(f"Failed to get risks aggregated apps free text filters, response code: {res.status_code} json: {res.json}")
            raise_from_response(res)
        return res

    def get_risks_aggregated_apps_auto_complete(self, **params):
        res = self.client.get(endpoint=RISKS_AGGREGATED_APPS_AUTO_COMPLETE, params=params)
        if res.status_code != 200:
            logging.info(f"Failed to get risks aggregated apps auto complete, response code: {res.status_code} json: {res.json}")
            raise_from_response(res)
        return res

    def get_risks_apps_export(self, **params):
        res = self.client.get(endpoint=RISKS_APPS_EXPORT, params=params)
        if res.status_code != 200:
            logging.info(f"Failed to export risks apps, response code: {res.status_code} json: {res.json}")
            raise_from_response(res)
        return res

    def get_risks_apps_filters_count(self, **params):
        res = self.client.get(endpoint=RISKS_APPS_FILTERS_COUNT, params=params)
        if res.status_code != 200:
            logging.info(f"Failed to get risk  apps filter count, response code: {res.status_code} json: {res.json}")
            raise_from_response(res)
        return res

    def get_risks_apps_free_text_filters(self, **params):
        res = self.client.get(endpoint=RISKS_APPS_FREE_TEXT_FILTERS, params=params)
        if res.status_code != 200:
            logging.info(f"Failed to get risk apps text filters, response code: {res.status_code} json: {res.json}")
            raise_from_response(res)
        return res

    def get_risks_apps_auto_complete(self, **params):
        res = self.client.get(endpoint=RISKS_APPS_AUTO_COMPLETE, params=params)
        if res.status_code != 200:
            logging.info(f"Failed to get risk apps auto complete, response code: {res.status_code} json: {res.json}")
            raise_from_response(res)
        return res

    def get_risks_endpoints_export(self, **params):
        res = self.client.get(endpoint=RISKS_ENDPOINTS_EXPORT, params=params)
        if res.status_code != 200:
            logging.info(f"Failed to export risk endpoints, response code: {res.status_code} json: {res.json}")
            raise_from_response(res)
        return res

    def get_risks_endpoints_filters_count(self, **params):
        res = self.client.get(endpoint=RISKS_ENDPOINTS_FILTERS_COUNT, params=params)
        if res.status_code != 200:
            logging.info(f"Failed to get risk endpoints filter count, response code: {res.status_code} json: {res.json}")
            raise_from_response(res)
        return res

    def get_risks_endpoints_free_text_filters(self, **params):
        res = self.client.get(endpoint=RISKS_ENDPOINTS_FREE_TEXT_FILTERS, params=params)
        if res.status_code != 200:
            logging.info(f"Failed to get risk endpoints free text filters, response code: {res.status_code} json: {res.json}")
            raise_from_response(res)
        return res

    def get_risks_endpoints_auto_complete(self, **params):
        res = self.client.get(endpoint=RISKS_ENDPOINTS_AUTO_COMPLETE, params=params)
        if res.status_code != 200:
            logging.info(f"Failed to get risk endpoints auto complete, response code: {res.status_code} json: {res.json}")
            raise_from_response(res)
        return res

    def get_risks_cves_export(self, **params):
        res = self.client.get(endpoint=RISKS_CVES_EXPORT, params=params)
        if res.status_code != 200:
            logging.info(f"Failed to export risk cves, response_code: {res.status_code}")
            raise_from_response(res)
        return res

    def get_risks_cves_extended_export(self, **params):
        res = self.client.get(endpoint=RISKS_CVES_EXTENDED_EXPORT, params=params)
        if res.status_code != 200:
            logging.info(f"Failed to export extended risk cves, response code: {res.status_code} json: {res.json}")
            raise_from_response(res)
        return res

    def get_risks_aggregated_apps_extended_export(self, **params):
        res = self.client.get(endpoint=RISKS_AGGREGATED_APPS_EXTENDED_EXPORT, params=params)
        if res.status_code != 200:
            logging.info(f"Failed to export extended aggregated apps, response code: {res.status_code} json: {res.json}")
            raise_from_response(res)
        return res

    def get_risks_cves_filters_count(self, **params):
        res = self.client.get(endpoint=RISKS_CVES_FILTERS_COUNT, params=params)
        if res.status_code != 200:
            logging.info(f"Failed to get risk cves filter counts, response code: {res.status_code} json: {res.json}")
            raise_from_response(res)
        return res

    def get_risks_cves_free_text_filters(self, **params):
        res = self.client.get(endpoint=RISKS_CVES_FREE_TEXT_FILTERS, params=params)
        if res.status_code != 200:
            logging.info(f"Failed to get risk cves text filters, response code: {res.status_code} json: {res.json}")
            raise_from_response(res)
        return res

    def get_risks_cves_auto_complete(self, **params):
        res = self.client.get(endpoint=RISKS_CVES_AUTO_COMPLETE, params=params)
        if res.status_code != 200:
            logging.info(f"Failed to get risk cves auto complete, response code: {res.status_code} json: {res.json}")
            raise_from_response(res)
        return res

    def update_risks_apps_fp(self, query_filter=None, **kwargs):
        """ Marks one or more CVEs as false positive for given application. """
        res = self.client.post(endpoint=RISKS_APPS_FP, payload={'filter': query_filter or {}}, data=kwargs)
        if res.status_code != 200 and res.status_code != 204:
            logging.info(f"Failed to update app with false positive cve, response code: {res.status_code} json: {res.json}")
            raise_from_response(res)
        return res

    def revert_risks_apps_fp(self, cve_id, query_filter=None, **kwargs):
        """ Removes a false positive CVE association from an application. """
        res = self.client.post(endpoint=RISKS_APPS_REVERT_FP.format(cve_id),
                               payload={'filter': query_filter or {}}, data=kwargs)
        if res.status_code != 200 and res.status_code != 204:
            logging.info(f"Failed to revert app false positive cve, response code: {res.status_code} json: {res.json}")
            raise_from_response(res)
        return res

    def update_risks_aggregated_apps_fp(self, query_filter=None, **kwargs):
        """ Marks one or more CVEs as false positive for given aggregated application view. """
        res = self.client.post(endpoint=RISKS_AGGREGATED_APPS_FP, payload={'filter': query_filter or {}}, data=kwargs)
        if res.status_code != 200 and res.status_code != 204:
            logging.info(f"Failed to update aggregated apps with false positive cve, response code: {res.status_code} json: {res.json}")
            raise_from_response(res)
        return res

    def revert_risks_aggregated_apps_fp(self, cve_id, query_filter=None, **kwargs):
        """ Removes a false positive CVE association from a aggregated applications view. """
        res = self.client.post(endpoint=RISKS_AGGREGATED_APPS_REVERT_FP.format(cve_id),
                               payload={'filter': query_filter or {}}, data=kwargs)
        if res.status_code != 200 and res.status_code != 204:
            logging.info(f"Failed to revert aggregated apps with false positive cve, response code: {res.status_code} json: {res.json}")
            raise_from_response(res)
        return res

    def get_risks_cve_by_id(self, **params):
        """ Searches for a CVE identified by CVE ID. The CVE ID is provided in a query parameter. """
        res = self.client.get(endpoint=RISKS_APPS_MISSING_CVE, params=params)
        if res.status_code != 200 and res.status_code != 404:
            logging.info(f"Failed get missing cve, response code: {res.status_code} json: {res.json}")
            raise_from_response(res)
        return res

    def update_risks_apps_missing_cve(self, query_filter=None, **kwargs):
        """ Associates an application with a CVE. """
        res = self.client.post(endpoint=RISKS_APPS_MISSING_CVE, payload={'filter': query_filter or {}}, data=kwargs)
        if res.status_code != 200 and res.status_code != 204:
            logging.info(f"Failed to update app with missing cve, response code: {res.status_code} json: {res.json}")
            raise_from_response(res)
        return res

    def revert_risks_apps_missing_cve(self, cve_id, query_filter=None, **kwargs):
        """ Removes a CVE association with an application. """
        res = self.client.post(endpoint=RISKS_APPS_REVERT_MISSING_CVE.format(cve_id),
                               payload={'filter': query_filter or {}}, data=kwargs)
        if res.status_code != 200 and res.status_code != 204:
            logging.info(f"Failed to revert app with missing cve, response code: {res.status_code} json: {res.json}")
            raise_from_response(res)
        return res

    def get_risks_teaser(self, **params):
        """ Returns the contents of the risk teaser box """
        res = self.client.get(endpoint=RISKS_TEASER, params=params)
        if res.status_code != 200:
            logging.info(f"Failed get risks teaser, response code: {res.status_code} json: {res.json}")
            raise_from_response(res)
        return res

    def update_risks_apps_statuses(self, query_filter=None, **params):
        res = self.client.post(endpoint=RISKS_APPS_STATUSES,
                               payload={'filter': query_filter or {}}, data=params)
        if res.status_code != 200:
            logging.info(f"Failed to update risk apps statuses, response code: {res.status_code} json: {res.json}")
            raise_from_response(res)
        return res

    def update_risks_aggregated_apps_statuses(self, query_filter=None, **params):
        res = self.client.post(endpoint=RISKS_AGGREGATED_APPS_STATUSES,
                               payload={'filter': query_filter or {}}, data=params)
        if res.status_code != 200:
            logging.info(f"Failed to update risk aggregated apps statuses, response code: {res.status_code} json: {res.json}")
            raise_from_response(res)
        return res

    def update_risks_endpoints_statuses(self, query_filter=None, **params):
        res = self.client.post(endpoint=RISKS_ENDPOINTS_STATUSES,
                               payload={'filter': query_filter or {}}, data=params)
        if res.status_code != 200:
            logging.info(f"Failed to update risk endpoints statuses, response code: {res.status_code} json: {res.json}")
            raise_from_response(res)
        return res

    def create_risks_endpoints_issues(self, query_filter=None, **params):
        """ Creates issues (e.g Jira) on filtered endpoints """
        res = self.client.post(endpoint=APP_ISSUES_ENDPOINTS,
                               payload={'filter': query_filter or {}}, data=params)
        if res.status_code != 200:
            logging.info(f"Failed to create risk endpoints issues, response code: {res.status_code} json: {res.json}")
            raise_from_response(res)
        return res

    def create_risks_applications_issues(self, query_filter=None, **params):
        """ Creates issues (e.g Jira) on filtered applications """
        res = self.client.post(endpoint=APP_ISSUES_APPLICATION,
                               payload={'filter': query_filter or {}}, data=params)
        if res.status_code != 200:
            logging.info(f"Failed to create risk applications issues, response code: {res.status_code} json: {res.json}")
            raise_from_response(res)
        return res
