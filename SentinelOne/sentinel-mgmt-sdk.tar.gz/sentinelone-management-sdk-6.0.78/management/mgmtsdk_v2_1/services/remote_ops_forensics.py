import http
import logging
from typing import Optional, Dict, Any

from management.common.query_filter import QueryFilter

from management.mgmtsdk_v2.client import ManagementResponse
from management.mgmtsdk_v2.exceptions import raise_from_response
from management.mgmtsdk_v2_1.entities.remote_ops_forensics import ForensicsCollectionProfile, \
    ForensicsCollectionProfileDetails
from management.mgmtsdk_v2_1.endpoints import \
    REMOTE_OPS_FORENSICS_IS_COLLECTION_FILE, REMOTE_OPS_FORENSICS_COLLECTION_FILE_URL, \
    REMOTE_OPS_FORENSICS_COLLECTION_PROFILES, REMOTE_OPS_FORENSICS_DESTINATION_PROFILES, \
    REMOTE_OPS_FORENSICS_GET_COLLECTION_BY_THREAT, REMOTE_OPS_FORENSICS_START_COLLECTION, \
    REMOTE_OPS_FORENSICS_GET_TASK_RESULT, REMOTE_OPS_FORENSICS_COLLECTION_PROFILE


class ForensicsCollectionProfilesQueryFilter(QueryFilter):
    QUERY_ARGS = {
        'ids': ['eq'],
        'osTypes': ['eq'],
        'tenant': ['eq'],
        'accountIds': ['eq'],
        'siteIds': ['eq'],
        'groupIds': ['eq'],
        'query': ['eq'],
        'limit': ['eq'],
        'cursor': ['eq'],
        'skip': ['eq'],
        'skipCount': ['eq'],
        'sortBy': ['eq'],
        'sortOrder': ['eq'],
    }


class RemoteOpsForensics(object):
    """Remote Ops Forensics service"""

    def __init__(self, client):
        self.client = client
        self._logger = logging.getLogger('RemoteOpsForensics')

    def is_collection_file(self, agent_id, storyline):
        """
        Check if a collection file exists for threat

        :type: agent_id: string
        :type: storyline: string
        :rtype: ManagementResponse
        """

        params = {'agentId': agent_id, 'storyline': storyline}
        res = self.client.get(endpoint=REMOTE_OPS_FORENSICS_IS_COLLECTION_FILE, params=params)
        if res.status_code != http.client.OK:
            self._logger.warning("Failed getting collection file details. response_code: {}".format(res.status_code))
            raise_from_response(res)
        return RemoteOpsForensicsIsCollectionFileContent(res.data['signature'], res.data['siteId'],
                                                         res.data['signatureType'], res.data['agentId'],
                                                         res.data['uploadedTimestamp'])

    def get_collection_by_threat(self, agent_id, storyline):
        """
        Get forensics collection data for specific agent by Storyline id of a threat

        :type: agent_id: string
        :type: storyline: string
        :rtype: ManagementResponse
        """

        params = {'agentId': agent_id, 'storylineId': storyline}
        res = self.client.get(endpoint=REMOTE_OPS_FORENSICS_GET_COLLECTION_BY_THREAT, params=params)
        if res.status_code != http.client.OK:
            self._logger.warning("Failed getting forensics collection data. response_code: {}".format(res.status_code))
            raise_from_response(res)

        collection_file = None
        if res.data.get('collectionFile') is not None:
            collection_file_data = res.data['collectionFile']
            collection_file = RemoteOpsForensicsCollectionFileData(
                collection_file_data['signature'],
                collection_file_data['siteId'],
                collection_file_data['signatureType'],
                collection_file_data['agentId'],
                collection_file_data['uploadedTimestamp'],
            )
        skylight_results_url = res.data.get('skylightResultsUrl')
        skylight_results_status = res.data.get('skylightResultsStatus')
        return RemoteOpsForensicsCollectionContent(collection_file, skylight_results_url, skylight_results_status)

    def collection_file_url(self, signature, site_id, signature_type, agent_id, uploaded_timestamp):
        """
        Check if a collection file exists for threat

        :type: signature: string
        :type: site_id: int
        :type: signature_type: string
        :type: agent_id: string
        :type: uploaded_timestamp: string
        :rtype: ManagementResponse
        """

        params = {'agentId': agent_id, 'signature': signature, 'siteId': site_id,
                  'signatureType': signature_type, 'uploadedTimestamp': uploaded_timestamp}
        res = self.client.get(endpoint=REMOTE_OPS_FORENSICS_COLLECTION_FILE_URL, params=params)
        if res.status_code != http.client.OK:
            self._logger.warning("Failed to get collection url. response_code: {}".format(res.status_code))
            raise_from_response(res)
        return RemoteOpsForensicsIsCollectionFileUrl(res.data['fileName'], res.data['downloadUrl'])

    def get_collection_profiles(self, query_filter=None, **filter_args):
        """
        Get list of Forensics collection profiles from the console by filters, default filter is empty

        :type query_filter: ForensicsCollectionProfilesQueryFilter
        :type filter_args: dict
        :rtype: ManagementResponse
        """
        query_params = ForensicsCollectionProfilesQueryFilter.get_query_params(query_filter, filter_args)
        res = self.client.get(endpoint=REMOTE_OPS_FORENSICS_COLLECTION_PROFILES, params=query_params)
        if res.status_code != 200:
            self._logger.warning(f"Failed to get Forensics collection profiles, response_code: {res.status_code}")
            raise_from_response(res)
        res.data = [ForensicsCollectionProfile(**profile) for profile in res.data]
        return res

    def get_collection_profile_details(self, profile_id):
        """
        Get Forensics collection profile details by id

        :type profile_id: int
        :rtype: ManagementResponse
        """
        res = self.client.get(endpoint=REMOTE_OPS_FORENSICS_COLLECTION_PROFILE.format(profile_id))
        if res.status_code != 200:
            self._logger.warning(f"Failed to get Forensics collection profile details, "
                                 f"response_code: {res.status_code}")
            raise_from_response(res)
        res.data = ForensicsCollectionProfileDetails(**res.data)
        return res

    def add_collection_profile(self, collection_profile):
        """
        add Forensics collection profile
        :param collection_profile:
        :rtype: ManagementResponse
        """
        res = self.client.post(endpoint=REMOTE_OPS_FORENSICS_COLLECTION_PROFILES, data=collection_profile)

        if res.status_code != 200:
            self._logger.warning(f"Failed to add collection profile, response_code: {res.status_code}")
            raise_from_response(res)
        res.data = ForensicsCollectionProfile(**res.data)
        return res.data

    def update_collection_profile(self, profile_id, collection_profile):
        """
        update Forensics collection profile
        :param collection_profile:
        :rtype: ManagementResponse
        """
        res = self.client.put(endpoint=REMOTE_OPS_FORENSICS_COLLECTION_PROFILE.format(profile_id),
                              data=collection_profile)

        if res.status_code != 200:
            self._logger.warning(f"Failed to add collection profile, response_code: {res.status_code}")
            raise_from_response(res)
        res.data = ForensicsCollectionProfile(**res.data)
        return res.data

    def delete_collection_profiles(self, profile_ids):
        """
        delete Forensics collection profiles by id
        :param profel_ids:
        :rtype: ManagementResponse
        """
        res = self.client.delete(endpoint=REMOTE_OPS_FORENSICS_COLLECTION_PROFILES, query_filter={'ids': profile_ids})

        if res.status_code != 200:
            self._logger.warning(f"Failed to delete collection profiles, response_code: {res.status_code}")
            raise_from_response(res)
        res.data = [ForensicsCollectionProfile(**profile) for profile in res.data]
        return res.data

    def add_destination_profile(self, destination_profile):
        """
        Add Skylight destination profile
        :param destination_profile:
        :rtype: ManagementResponse
        """

        res = self.client.post(endpoint=REMOTE_OPS_FORENSICS_DESTINATION_PROFILES, payload=destination_profile)

        if res.status_code != 200:
            self._logger.warning(f"Failed to create destinatino profile, response_code: {res.status_code}")
            raise_from_response(res)
        return res

    def get_destination_profiles(self, scope_id: int, scope_level: str):
        """
        Add Skylight destination profile
        :param destination_profile:
        :rtype: ManagementResponse
        """

        res = self.client.get(endpoint=REMOTE_OPS_FORENSICS_DESTINATION_PROFILES, params={
            'scopeId': scope_id,
            'scopeLevel': scope_level,
        })

        if res.status_code != 200:
            self._logger.warning(f"Failed to get destinatino profiles, response_code: {res.status_code}")
            raise_from_response(res)
        return res

    def run_collection(self, payload):
        """
        Start collection on endpoints
        :param payload:
        :rtype: ManagementResponse
        """
        res = self.client.post(endpoint=REMOTE_OPS_FORENSICS_START_COLLECTION, payload=payload)

        if res.status_code != 202:
            self._logger.warning(f"Failed to start forensics collection, response_code: {res.status_code}")
            raise_from_response(res)
        return res

    def get_task_result(self, task_id: int):
        """
        Get collection task results by id
        :param task_id:
        :rtype: ManagementResponse
        """
        res = self.client.get(endpoint=f"{REMOTE_OPS_FORENSICS_GET_TASK_RESULT}?taskId={task_id}")

        if res.status_code != 200:
            self._logger.warning(f"Failed to fetch forensics collection by task id, response_code: {res.status_code}")
            raise_from_response(res)
        return res


class RemoteOpsForensicsCollectionFileData:
    def __init__(self, signature: str, site_id: int, signature_type: str, agent_id: str, uploaded_timestamp: str):
        self.signature = signature
        self.site_id = site_id
        self.signature_type = signature_type
        self.agent_id = agent_id
        self.uploaded_timestamp = uploaded_timestamp


class RemoteOpsForensicsIsCollectionFileContent(RemoteOpsForensicsCollectionFileData):
    pass


class RemoteOpsForensicsCollectionContent:
    def __init__(self, collection_file: Optional[RemoteOpsForensicsCollectionFileData],
                 skylight_results_url: Optional[str], skylight_results_status: Optional[Dict[str, Any]]):
        self.collection_file = collection_file
        self.skylight_results_url = skylight_results_url
        self.skylight_results_status = skylight_results_status


class RemoteOpsForensicsIsCollectionFileUrl:
    def __init__(self, file_name, download_url):
        self.file_name = file_name
        self.download_url = download_url
