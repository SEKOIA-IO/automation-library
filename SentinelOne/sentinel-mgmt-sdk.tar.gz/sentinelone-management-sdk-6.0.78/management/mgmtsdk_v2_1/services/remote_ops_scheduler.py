import logging
from typing import Optional, List, Dict, Any
from six.moves import http_client as httplib

from management.common.query_filter import QueryFilter

from management.mgmtsdk_v2.client import ManagementResponse
from management.mgmtsdk_v2.exceptions import raise_from_response
from management.mgmtsdk_v2_1.endpoints import REMOTE_OPS_SCHEDULE_REMOTE_SCRIPT, REMOTE_OPS_SCHEDULED_TASKS

logger = logging.getLogger('RemoteOpsScheduler')

class ScheduledTasksQueryFilter(QueryFilter):
    QUERY_ARGS = {
        'ids': ['eq'],
        'tenant': ['eq'],
        'accountIds': ['eq'],
        'siteIds': ['eq'],
        'groupIds': ['eq'],
        'limit': ['eq'],
        'cursor': ['eq'],
        'skip': ['eq'],
        'skipCount': ['eq'],
        'sortBy': ['eq'],
        'sortOrder': ['eq'],
    }

    def __init__(self):
        super(ScheduledTasksQueryFilter, self).__init__()

class RemoteOpsScheduler(object):
    """Remote Ops scheduler service"""
    def __init__(self, client):
        self.client = client
        self._logger = logging.getLogger('RemoteOpsScheduler')

    def schedule_remote_script(self, execute_script_data: dict, schedule_definition: dict, agent_filter: dict,
                               action_scope: Optional[dict]=None) -> ManagementResponse:
        """
        Schedule remote script for execution
        :param execute_script_data: data for execution
        :param action_scope: scope of action, if ommited default scope provided by S1 will be used
        :param schedule_definition: schedule definition
        :rtype: ManagementResponse
        """
        if action_scope is None:
            action_scope = {}
        payload = {
            'data':{
                'action': execute_script_data,
                'scheduling': schedule_definition,
                'actionScope': action_scope
            },
            'filter': agent_filter,
        }
        res = self.client.post(endpoint=REMOTE_OPS_SCHEDULE_REMOTE_SCRIPT, payload=payload)

        if res.status_code != httplib.OK:
            self._logger.warning(f"Failed to schedule remote script for execution, response_code: {res.status_code}")
            raise_from_response(res)
        return res

    def get_scheduled_tasks(self, query_filter: Optional[ScheduledTasksQueryFilter] = None, **filter_args):
        """
        Get pending executions according to the filter.
        :param query_filter: Optional[ScheduledTasksQueryFilter]
        :param filter_args: dict
        :rtype: ManagementResponse
        """
        query_params = ScheduledTasksQueryFilter.get_query_params(query_filter, filter_args)
        res = self.client.get(endpoint=REMOTE_OPS_SCHEDULED_TASKS, params=query_params)
        if res.status_code != httplib.OK:
            logger.warning("Failed to get scheduled tasks. response_code: {}".format(res.status_code))
            raise_from_response(res)
        return res

    def delete_scheduled_tasks(self, tasks_ids: List[str]) -> ManagementResponse:
        """
        delete scheduled tasks by id
        :param tasks_ids:
        :rtype: ManagementResponse
        """
        res = self.client.delete(endpoint=REMOTE_OPS_SCHEDULED_TASKS, query_filter={'ids': tasks_ids})

        if res.status_code != httplib.OK:
            self._logger.warning(f"Failed to delete scheduled tasks, response_code: {res.status_code}")
            raise_from_response(res)
        return res

    def update_scheduled_task(self, task_id: str, scheduling: Dict[str, Any]) -> ManagementResponse:
        """
        Update scheduled task
        :param task_id:
        :param scheduling:
        :rtype: ManagementResponse
        """
        res = self.client.put(endpoint=f'{REMOTE_OPS_SCHEDULED_TASKS}/{task_id}',
                              payload=scheduling)

        if res.status_code != httplib.OK:
            self._logger.warning(f"Failed to update scheduled task, response_code: {res.status_code}")
            raise_from_response(res)
        return res
