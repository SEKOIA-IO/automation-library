import logging

from management.common.query_filter import QueryFilter
from management.mgmtsdk_v2.exceptions import raise_from_response
from management.mgmtsdk_v2_1.endpoints import CLOUD_ROGUES_TABLE, CLOUD_ROGUES_EXPORT
from management.mgmtsdk_v2_1.entities.cloud_rogues import CloudRoguesResource


class CloudRoguesFilter(QueryFilter):
    QUERY_ARGS = {
        'osTypes': ['eq'],
        'region': ['eq', 'contains'],
        'cloudProviderAccountName': ['eq', 'contains'],
        'cloudProviderName': ['eq'],
        'cloudProviderAccountId': ['contains'],
        'id': ['contains'],
        'image': ['contains'],
        'virtual_network_id': ['contains'],
        'name': ['contains'],
        'accountIds': ['eq'],
        'siteIds': ['eq'],
        'limit': ['eq'],
        'skip': ['eq'],
        'cursor': ['eq'],
        'countOnly': ['eq'],
        'skipCount': ['eq'],
        'sortBy': ['eq'],
        'sortOrder': ['eq'],
    }

    def __init__(self):
        super(CloudRoguesFilter, self).__init__()


class CloudRoguesExportFilter(CloudRoguesFilter):

    def __init__(self):
        self.QUERY_ARGS.update({
            'exportFormat': ['eq'],
        })
        super(CloudRoguesExportFilter, self).__init__()


class CloudRogues(object):
    """API for Cloud Rogues provided by CWS Service"""

    def __init__(self, client):
        self.client = client
        self._logger = logging.getLogger('CloudRogues')

    def get(self, query_filter=None, **cloud_rogues_args):
        """
        Get cloud resources table for given cloud rogues filters, default filter is empty
        """
        query_params = CloudRoguesFilter.get_query_params(query_filter, cloud_rogues_args)
        res = self.client.get(endpoint=CLOUD_ROGUES_TABLE, params=query_params)
        if res.status_code != 200:
            self._logger.warning("Failed to get cloud rogues table, response_code: {}".format(res.status_code))
            raise_from_response(res)
        res.data = [CloudRoguesResource(**cloud_rogues) for cloud_rogues in res.data.get('resources', [])]
        return res

    def export(self, query_filter=None, **cloud_rogues_args):
        """
        Get cloud resources table in csv or json format
        """
        query_params = CloudRoguesExportFilter.get_query_params(query_filter, cloud_rogues_args)
        res = self.client.get(endpoint=CLOUD_ROGUES_EXPORT, params=query_params)
        if res.status_code != 200:
            self._logger.warning("Failed to perform cloud rogues export, response_code: {}".format(res.status_code))
            raise_from_response(res)
        res.content_type = self.__get_content_type(res)
        if res.data is None and res.content_type != 'application/json':
            res.data = res.response.text
        return res

    @staticmethod
    def __get_content_type(request_result):
        return dict(request_result.response.headers).get('Content-Type', '')
