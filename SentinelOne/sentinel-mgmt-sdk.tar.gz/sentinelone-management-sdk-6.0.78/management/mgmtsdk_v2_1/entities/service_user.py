class ApiToken(object):
    def __init__(self, **kwargs):
        self.expiresAt = kwargs.get('expiresAt', None)
        self.createdAt = kwargs.get('createdAt', None)
        if kwargs.get('value', None):
            self.value = kwargs.get('value')
        if 'elevated' in kwargs:
            self.elevated = kwargs.get('elevated')


class ServiceUser(object):
    def __init__(self, **kwargs):
        self.apiToken = ApiToken(**kwargs.get('apiToken', None))
        self.createdAt = kwargs.get('createdAt', None)
        self.description = kwargs.get('description', None)
        self.id = kwargs.get('id', None)
        if kwargs.get('lastActivation', None):
            self.lastActivation = kwargs.get('lastActivation', None)
        self.name = kwargs.get('name', None)
        self.scope = kwargs.get('scope', None)
        self.scopeRoles = kwargs.get('scopeRoles', None)
        self.updatedAt = kwargs.get('updatedAt', None)
