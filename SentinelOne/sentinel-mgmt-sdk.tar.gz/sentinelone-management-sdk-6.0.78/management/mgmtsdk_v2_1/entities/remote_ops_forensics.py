class ForensicsCollectionProfile(object):
    def __init__(self, **kwargs):
        self.createdAt = kwargs.get('createdAt', None)
        self.creator = kwargs.get('creator', None)
        self.creatorId = kwargs.get('creatorId', None)
        self.description = kwargs.get('description', None)
        self.id = kwargs.get('id', None)
        self.isBundled = kwargs.get('isBundled', None)
        self.name = kwargs.get('name', None)
        self.osTypes = kwargs.get('osTypes', None)
        self.scopeId = kwargs.get('scopeId', None)
        self.scopeLevel = kwargs.get('scopeLevel', None)
        self.scopePath = kwargs.get('scopePath', None)
        self.updatedAt = kwargs.get('updatedAt', None)
        self.updater = kwargs.get('updater', None)
        self.updaterId = kwargs.get('updaterId', None)
        self.version = kwargs.get('version', None)


class ForensicsCollectionProfileDetails(ForensicsCollectionProfile):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.artifacts = kwargs.get('artifacts', None)
