
class RiskDataTypes:
    VULN_DETAILS = 'vulnerabilityDetails'
    VULN_TIMELINE = 'vulnerabilityTimeline'
    VULN_INDICATORS = 'vulnerabilityIndicators'
    ENDPOINT_DETAILS = 'endpointDetails'
    RISK_SCORE = 'riskScore'


class Risk(object):

    def __init__(self, **kwargs):
        self.id = kwargs.get('id')
        self.cveId = kwargs.get('cveId')
        self.osType = kwargs.get('osType')
        self.endpointId = kwargs.get('endpointId')
        self.endpointName = kwargs.get('endpointName')
        self.endpointType = kwargs.get('endpointType')
        self.application = kwargs.get('application')
        self.applicationName = kwargs.get('applicationName')
        self.applicationVendor = kwargs.get('applicationVendor')
        self.publishedDate = kwargs.get('publishedDate')
        self.baseScore = kwargs.get('baseScore')
        self.cvssVersion = kwargs.get('cvssVersion')
        self.severity = kwargs.get('severity')
        self.daysDetected = kwargs.get('daysDetected')
        self.detectedDate = kwargs.get('detectedDate')
        self.lastScanResult = kwargs.get('lastScanResult')
        self.lastScanDate = kwargs.get('lastScanDate')
        # Visible only if temporal enrichment is ON
        self.riskScore = kwargs.get('riskScore')
        self.nvdBaseScore = kwargs.get('nvdBaseScore')
        self.exploitCodeMaturity = kwargs.get('exploitCodeMaturity')
        self.remediationLevel = kwargs.get('remediationLevel')
        self.reportConfidence = kwargs.get('reportConfidence')

    def __repr__(self):
        return f'<management.mgmtsdk_v2_1.entities.app_management.Risk: {self.id} - {self.cveId}>'


class VulnDetails(object):

    def __init__(self, **kwargs):
        self.type = kwargs.get('type')
        self.order = kwargs.get('order')
        self.cveId = kwargs.get('cveId')
        self.application = kwargs.get('application')
        self.applicationName = kwargs.get('applicationName')
        self.applicationVendor = kwargs.get('applicationVendor')
        self.baseScore = kwargs.get('baseScore')
        self.riskScore = kwargs.get('riskScore')
        self.cvssVersion = kwargs.get('cvssVersion')
        self.severity = kwargs.get('severity')
        self.daysDetected = kwargs.get('daysDetected')
        self.detectedDate = kwargs.get('detectedDate')
        self.publishedDate = kwargs.get('publishedDate')
        self.vulnerabilityDescription = kwargs.get('vulnerabilityDescription')
        self.mitreUrl = kwargs.get('mitreUrl')
        self.nvdUrl = kwargs.get('nvdUrl')

    def __repr__(self):
        return f'<management.mgmtsdk_v2_1.entities.app_management.VulnDetails: {self.cveId}>'


class EndpointDetails(object):

    def __init__(self, **kwargs):
        self.type = kwargs.get('type')
        self.order = kwargs.get('order')
        self.endpointId = kwargs.get('endpointId')
        self.endpointName = kwargs.get('endpointName')
        self.endpointType = kwargs.get('endpointType')
        self.osType = kwargs.get('osType')
        self.domain = kwargs.get('domain')
        self.installationPath = kwargs.get('installationPath')
        self.accountName = kwargs.get('accountName')
        self.siteName = kwargs.get('siteName')
        self.groupName = kwargs.get('groupName')

    def __repr__(self):
        return f'<management.mgmtsdk_v2_1.entities.app_management.EndpointDetails: {self.endpointId}>'


class RiskScore(object):

    def __init__(self, **kwargs):
        self.type = kwargs.get('type')
        self.order = kwargs.get('order')
        self.riskScore = kwargs.get('riskScore')
        self.nvdBaseScore = kwargs.get('nvdBaseScore')
        self.severity = kwargs.get('severity')
        self.baseScore = kwargs.get('baseScore')
        self.temporalScore = kwargs.get('temporalScore')
        self.exploitCodeMaturity = kwargs.get('exploitCodeMaturity')
        self.remediationLevel = kwargs.get('remediationLevel')
        self.reportConfidence = kwargs.get('reportConfidence')
        self.isExploitedInTheWild = kwargs.get('isExploitedInTheWild')
        self.attackVectors = kwargs.get('attackVectors', {})

    def __repr__(self):
        return f'<management.mgmtsdk_v2_1.entities.app_management.RiskScore: {self.riskScore}>'


class VulnTimeline(object):

    def __init__(self, **kwargs):
        self.type = kwargs.get('type')
        self.order = kwargs.get('order')
        self.vulnerabilityIdentified = kwargs.get('vulnerabilityIdentified')
        self.cveAssigned = kwargs.get('cveAssigned')
        self.advisoryPublished = kwargs.get('advisoryPublished')
        self.mitigationPublished = kwargs.get('mitigationPublished')
        self.pocPublished = kwargs.get('pocPublished')
        self.exploitedInTheWild = kwargs.get('exploitedInTheWild')

    def __repr__(self):
        return f'<management.mgmtsdk_v2_1.entities.app_management.VulnTimeline: {self.type}>'


class VulnIndicators(object):

    def __init__(self, **kwargs):
        self.type = kwargs.get('type')
        self.order = kwargs.get('order')
        self.cveId = kwargs.get('cveId')
        self.data = kwargs.get('data', [])

    def __repr__(self):
        return f'<management.mgmtsdk_v2_1.entities.app_management.VulnIndicators: {self.cveId}>'


def get_risk_data_class(data_type, **kwargs):
    data = kwargs
    if data_type == RiskDataTypes.VULN_DETAILS:
        data = VulnDetails(**kwargs)
    elif data_type == RiskDataTypes.VULN_TIMELINE:
        data = VulnTimeline(**kwargs)
    elif data_type == RiskDataTypes.VULN_INDICATORS:
        data = VulnIndicators(**kwargs)
    elif data_type == RiskDataTypes.ENDPOINT_DETAILS:
        data = EndpointDetails(**kwargs)
    elif data_type == RiskDataTypes.RISK_SCORE:
        data = RiskScore(**kwargs)
    return data
