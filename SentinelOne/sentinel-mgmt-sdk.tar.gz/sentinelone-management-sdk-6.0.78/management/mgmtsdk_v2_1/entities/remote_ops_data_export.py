class DestinationProfile(object):
    def __init__(self, **kwargs):
        self.id = kwargs.get('id', None)
        self.name = kwargs.get('name', None)
        self.isDefault = kwargs.get('isDefault', None)
        self.destinationType = kwargs.get('destinationType', None)
        self.apiKey = kwargs.get('apiKey', None)
        self.apiUrl = kwargs.get('apiUrl', None)
        self.scopePath = kwargs.get('scopePath', None)
        self.creator = kwargs.get('creator', None)
        self.creatorId = kwargs.get('creatorId', None)
        self.updater = kwargs.get('updater', None)
        self.updaterId = kwargs.get('updaterId', None)
