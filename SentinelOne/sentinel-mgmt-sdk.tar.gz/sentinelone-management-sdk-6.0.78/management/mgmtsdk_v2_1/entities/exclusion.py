import six


class Exclusion(object):
    def __init__(self, **kwargs):
        self.actions = kwargs.get('actions', None)
        self.createdAt = kwargs.get('createdAt', None)
        self.description = kwargs.get('description', None)
        self.id = kwargs.get('id', None)
        self.inject = kwargs.get('inject', None)
        self.mode = kwargs.get('mode', None)
        self.osType = kwargs.get('osType', None)
        self.pathExclusionType = kwargs.get('pathExclusionType', None)
        self.scope = kwargs.get('scope', None)
        self.scopeName = kwargs.get('scopeName', None)
        self.source = kwargs.get('source', None)
        self.type = kwargs.get('type', None)
        self.updatedAt = kwargs.get('updatedAt', None)
        self.userId = kwargs.get('userId', None)
        self.userName = kwargs.get('userName', None)
        self.value = kwargs.get('value', None)

    def to_json(self):
        orig_json = self.__dict__
        for key in list(orig_json):
            if key in ['createdAt', 'updatedAt']:
                del orig_json[key]
        non_empty_json = {k: v for (k, v) in six.iteritems(orig_json) if v is not None}
        return non_empty_json


class UnifiedExclusion(object):
    def __init__(self, **kwargs):
        self.actions = kwargs.get('actions', None)
        self.childProcess = kwargs.get('childProcess', None)
        self.conditions = kwargs.get('conditions', None)
        self.createdAt = kwargs.get('createdAt', None)
        self.description = kwargs.get('description', None)
        self.engines = kwargs.get('engines', None)
        self.exclusionName = kwargs.get('exclusionName', None)
        self.exclusionType = kwargs.get('exclusionType', None)
        self.id = kwargs.get('id', None)
        self.interactionLevel = kwargs.get('interactionLevel', None)
        self.modeType = kwargs.get('modeType', None)
        self.osType = kwargs.get('osType', None)
        self.pathExclusionType = kwargs.get('pathExclusionType', None)
        self.reason = kwargs.get('reason', None)
        self.scope = kwargs.get('scope', None)
        self.scopeLevelName = kwargs.get('scopeLevelName', None)
        self.scopeName = kwargs.get('scopeName', None)
        self.source = kwargs.get('source', None)
        self.type = kwargs.get('type', None)
        self.updatedAt = kwargs.get('updatedAt', None)
        self.userId = kwargs.get('userId', None)
        self.userName = kwargs.get('userName', None)
        self.value = kwargs.get('value', None)

    def to_json(self):
        orig_json = self.__dict__
        for key in list(orig_json):
            if key in ['createdAt', 'updatedAt', 'id']:
                del orig_json[key]

        non_empty_json = {k: v for (k, v) in six.iteritems(orig_json) if v is not None}
        return non_empty_json


class Condition(object):

    def __init__(self, **kwargs):
        self.processOrService = kwargs.get('processOrService', None)
        self.hosts = kwargs.get('hosts', None)
        self.users = kwargs.get('users', None)

    def to_json(self):
        data = self.__dict__
        return data


class ProcessOrService(object):

    def __init__(self, **kwargs):
        self.name = kwargs.get('name', None)
        self.main = kwargs.get('main', None)
        self.parent = kwargs.get('parent', None)

    def to_json(self):
        data = self.__dict__
        return data


class ProcessOrServiceMain(object):
    def __init__(self, **kwargs):
        self.commandLine = kwargs.get('commandLine', None)
        self.includeSubfolders = kwargs.get('includeSubfolders', None)
        self.includeSubprocesses = kwargs.get('includeSubprocesses', None)
        self.processName = kwargs.get('processName', None)
        self.processPath = kwargs.get('processPath', None)
        self.publisher = kwargs.get('publisher', None)
        self.query = kwargs.get('query', None)
        self.service = kwargs.get('service', None)
        self.serviceName = kwargs.get('serviceName', None)
        self.workingDirectory = kwargs.get('workingDirectory', None)

    def to_json(self):
        data = self.__dict__
        return data
