import logging
from management.common.query_filter import QueryFilter
from management.mgmtsdk_v2.endpoints import RBAC_GET_USER_ROLE, RBAC_GET_ROLES, RBAC_GET_USER_PERMISSIONS
from management.mgmtsdk_v2.exceptions import raise_from_response

logger = logging.getLogger('Rbac')


class RbacQueryFilter(QueryFilter):
    QUERY_ARGS = {
        'ids': ['eq'],
        'accountIds': ['eq'],
        'siteIds': ['eq'],
        'groupIds': ['eq'],
        'roleIds': ['eq'],
        'query': ['eq'],
        'limit': ['eq'],
        'sortBy': ['eq'],
        'sortOrder': ['eq'],
        'permissionIds': ['eq'],
        'name': ['eq'],
        'id': ['eq'],
    }

    def __init__(self):
        super(RbacQueryFilter, self).__init__()


class Rbac(object):
    """Rbac service"""

    def __init__(self, client):
        self.client = client

    def get_rbac_roles(self, query_filter=None, **kwargs):
        query_params = RbacQueryFilter.get_query_params(query_filter, kwargs)
        res = self.client.get(endpoint=RBAC_GET_ROLES, params=query_params)
        if res.status_code != 200:
            logging.warning("Failed to Get rbac roles, response_code: {}".format(res.json))
            raise_from_response(res)
        return res

    def get_rbac_role(self, query_filter=None, **kwargs):
        query_params = RbacQueryFilter.get_query_params(query_filter, kwargs)
        res = self.client.get(endpoint=RBAC_GET_USER_ROLE.format(kwargs['id']), params=query_params)
        if res.status_code != 200:
            logging.warning("Failed to Get rbac role, response_code: {}".format(res.json))
            raise_from_response(res)
        return res

    def get_rbac_fe_role(self, query_filter=None, **kwargs):
        query_params = RbacQueryFilter.get_query_params(query_filter, kwargs)
        res = self.client.get(endpoint=RBAC_GET_USER_PERMISSIONS, params=query_params)
        if res.status_code != 200:
            logging.warning("Failed to Get rbac FE role, response_code: {}".format(res.json))
            raise_from_response(res)
        return res
