import logging
from datetime import datetime, timedelta

from management.common.query_filter import QueryFilter
from management.mgmtsdk_v2.endpoints import *
from management.mgmtsdk_v2.exceptions import raise_from_response

logger = logging.getLogger('DeviceControl')


class StatelessFilter(QueryFilter):
    QUERY_ARGS = {
        'accountIds': ['eq'],
        'action': ['eq'],
        'application': ['contains'],
        'countOnly': ['eq'],
        'createdAt': ['gt', 'gte', 'lt', 'lte'],
        'cursor': ['eq'],
        'deviceClass': ['eq'],
        'groupIds': ['eq'],
        'ids': ['eq'],
        'interface': ['eq'],
        'limit': ['eq'],
        'name': ['contains'],
        'osType': ['eq'],
        'osTypes': ['eq'],
        'productId': ['eq'],
        'query': ['eq'],
        'ruleName': ['eq'],
        'scopes': ['eq'],
        'service': ['contains'],
        'serviceClass': ['eq'],
        'siteIds': ['eq'],
        'skip': ['eq'],
        'skipCount': ['eq'],
        'sortBy': ['eq'],
        'sortOrder': ['eq'],
        'status': ['eq'],
        'tagIds': ['eq'],
        'tagName': ['contains'],
        'tenant': ['eq'],
        'uId': ['eq'],
        'vendorId': ['eq'],
    }

    def __init__(self):
        super(StatelessFilter, self).__init__()


class Stateless(object):
    """Stateless site api"""

    def __init__(self, client):
        self.client = client

    def get_site_authorization(self, site_id):
        """
            get all the authorized agents at the site
        """
        res = self.client.get(endpoint=APPROVE_STATELESS_UPGRADE_SITE.format(site_id))
        if res.status_code != 200:
            logger.warning(":failed to get all site authorization {}".format(res.json))
            raise_from_response(res)
        return res

    def get_site_csv(self, site_id):
        """
            download CSV file
        """
        res = self.client.get(endpoint=LOCAL_UPGRADE_APPROVE_AGENS_CSV.format(site_id))
        if res.status_code != 200:
            logger.warning(":failed to download CSV file {}".format(res.json))
            raise_from_response(res)
        return res

    def edit_site_authorization(self, site_id, expiration):
        """
            create site authorization
        """

        payload = {
            'siteAuthorization': expiration
        }

        res = self.client.put(endpoint=APPROVE_STATELESS_UPGRADE_SITE.format(site_id), payload=payload)
        if res.status_code != 200:
            logger.warning("Failed to edit site authorization, response_code: {}".format(res.json))
            raise_from_response(res)
        return res

    def edit_agent_authorization(self, agent_authorization: str, ids: list, os_type: 'str' = None,
                                 scope_level: str = None, scope_id: str = None):
        """
            create agent authorization
        """
        filters = {}
        if os_type:
            filters['osTypes'] = os_type
        if scope_level == 'global':
            filters['tenant'] = True
        if scope_level == 'account':
            filters['accountIds'] = scope_id
        if scope_level == 'site':
            filters['siteIds'] = scope_id
        if ids is not None:
            filters['ids'] = ids
        payload = {
            'data': {'agentAuthorization': agent_authorization},
            'filter': filters
        }

        res = self.client.post(endpoint=APPROVE_STATELESS_UPGRADE_AGENT, payload=payload)
        if res.status_code != 200:
            logger.warning("Failed to edit agent authorization, response_code: {}".format(res.json))
            raise_from_response(res)
        return res
