import json
import logging

from management.common.query_filter import QueryFilter
from management.mgmtsdk_v2.endpoints import *
from management.mgmtsdk_v2.entities.exclusions_catalog import ApplicationCatalog

from management.mgmtsdk_v2.exceptions import raise_from_response

logger = logging.getLogger('ExclusionsCatalog')


class ExclusionsCatalogQueryFilter(QueryFilter):
    QUERY_ARGS = {
        'tenant': ['eq'],
        'accountIds': ['eq'],
        'siteIds': ['eq'],
        'groupIds': ['eq'],

        'applicationNames': ['eq'],
        'query': ['eq'],
        'types': ['eq'],
        'osTypes': ['eq'],
        'inAppInventory': ['eq'],
        'exclusionStatuses': ['eq'],

        'limit': ['eq'],
        'skip': ['eq'],
        'sortBy': ['eq'],
        'sortOrder': ['eq'],
    }

    def __init__(self):
        super(ExclusionsCatalogQueryFilter, self).__init__()


class ApplicationsCatalogQueryFilter(QueryFilter):
    """
    Applications Catalog Query Filter for Exclusions Applications Catalog Endpoints:
    private/exclusions/applications-catalog
    private/exclusions/applications-catalog/filters-autocomplete
    """
    QUERY_ARGS = {
        "tenant": ["eq"],
        "accountIds": ["eq"],
        "siteIds": ["eq"],
        "groupIds": ["eq"],

        "vendor__contains": ["eq"],
        "value__contains": ["eq"],
        "description__contains": ["eq"],

        "applicationName_contains": ["eq"],
        "osTypes": ["eq"],
        "types": ["eq"],
        "mode": ["eq"],
        "exclusionType": ["eq"],
        "exclusionMode": ["eq"],

        "lastUpdated": ["eq"],
        "inAppInventory": ["eq"],
        "applicationNames": ["eq"],
        "exclusionStatuses": ["eq"],

        "key": ["eq"],
        "text": ["eq"],

        "limit": ["eq"],
        "skip": ["eq"],
        "sortBy": ["eq"],
        "sortOrder": ["eq"],
    }

    def __init__(self):
        super(ApplicationsCatalogQueryFilter, self).__init__()


APPLICATION_CATALOG_FREETEXT_FILTERS_TITLES = ("Application Name", "Vendor", "Attribute", "Description")


class ExclusionsCatalog(object):

    def __init__(self, client):
        self.client = client

    def get_catalog(self,
                    query_filter=None,
                    **excl_args):
        """
        :param query_filter: Query filter object
        :type query_filter: ExclusionsCatalogQueryFilter
        :return: Exclusions answering the query
        :rtype: ManagementResponse
        """

        query_params = ExclusionsCatalogQueryFilter.get_query_params(query_filter, excl_args)
        ret = list()
        res = self.client.get(endpoint=EXCLUSIONS_CATALOG, params=query_params)
        if res.status_code != 200:
            logger.warning(f"Failed to get exclusions catalog, response_code: {json.dumps(obj=res.json)}")
            raise_from_response(res)
        applications_catalog = res.data
        for app_object in applications_catalog:
            ret.append(ApplicationCatalog(**app_object))
            res.data = ret
        return res

    def add_exclusions_from_catalog(self,
                                    exclusion_ids=None,
                                    application_ids=None,
                                    add_all=False,
                                    query_filter=None,
                                    **excl_args):
        """
        :param exclusion_ids: exclusion ids from catalog
        :type exclusion_ids: List
        :param application_ids: application ids from catalog
        :type application_ids: List
        :param add_all: indicator to add all exclusions in the catalog
        :type add_all: Boolean
        :param query_filter: Query filter object
        :type query_filter: ExclusionCatalogQueryFilter
        :param excl_args: Key value with query filters
        :type excl_args: **dict
        :return: num of exclusions that were added
        :rtype: ManagementResponse
        """
        if application_ids is None:
            application_ids = []
        if exclusion_ids is None:
            exclusion_ids = []
        query_params = ExclusionsCatalogQueryFilter.get_query_params(query_filter, excl_args)
        data = {'exclusionIds': exclusion_ids,
                'applicationIds': application_ids,
                'addAll': add_all}
        res = self.client.post(endpoint=EXCLUSIONS_CATALOG, data=data, query_filter=query_params)
        if res.status_code != 200:
            logger.warning(f"Failed to add exclusions from catalog, response_code: {json.dumps(obj=res.json)}")
            raise_from_response(res)
        res.data = int(res.data['affected'])
        return res

    def get_catalog_categories(self):
        """
        :return: Exclusion Catalog Categories and Versions.
        :rtype: ManagementResponse
        """
        res = self.client.get(endpoint=EXCLUSIONS_CATALOG_CATEGORIES)
        if res.status_code != 200:
            logger.warning(f"Failed to get exclusions catalog categories, response_code: {json.dumps(obj=res.json)}")
            raise_from_response(res)

        return res

    def get_filters_count(self,
                          query_filter=None,
                          **excl_args):
        """
        :rtype: ManagementResponse
        """
        query_params = ApplicationsCatalogQueryFilter.get_query_params(query_filter, excl_args)
        res = self.client.get(endpoint=EXCLUSIONS_CATALOG_FILTERS_COUNT, params=query_params)
        if res.status_code != 200:
            logger.warning(
                f"Failed to get exclusions catalog categories filter count, response_code: {json.dumps(obj=res.json)}")
            raise_from_response(res)
        return res

    def get_free_text_filters(self):
        """
        :rtype: ManagementResponse
        """
        res = self.client.get(endpoint=EXCLUSIONS_CATALOG_FREE_TEXT_FILTERS)
        if res.status_code != 200:
            logger.warning(
                f"Failed to get exclusions catalog categories free text filters, "
                f"response_code: {json.dumps(obj=res.json)}")
            raise_from_response(res)
        return res

    def get_filters_autocomplete(self,
                                 query_filter=None,
                                 **excl_args):
        query_params = ApplicationsCatalogQueryFilter.get_query_params(query_filter, excl_args)
        res = self.client.get(endpoint=EXCLUSIONS_CATALOG_FILTERS_AUTOCOMPLETE, params=query_params)
        if res.status_code != 200:
            logger.warning(
                f"Failed to get exclusions catalog categories filters autocomplete, "
                f"response_code: {json.dumps(obj=res.json)}")
            raise_from_response(res)
        return res
