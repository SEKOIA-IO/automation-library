class ApplicationCatalog(object):
    def __init__(self, **kwargs):
        self.appId = kwargs.get("appId", None)
        self.applicationName = kwargs.get("applicationName", None)
        self.numberOfEndpoints = kwargs.get("numberOfEndpoints", None)
        self.vendor = kwargs.get("vendor", None)
        self.inAppInventory = kwargs.get("inAppInventory", None)
        self.exclusionsStatus = kwargs.get("exclusionsStatus", None)
        self.categoryIds = kwargs.get("categoryIds", None)
        if exclusions := kwargs.get("exclusions"):
            self.exclusions = []
            self.exclusions += [ApplicationExclusions(**ex) for ex in exclusions]


class ApplicationExclusions(object):
    def __init__(self, **kwargs):
        self.id = kwargs.get("id", None)
        self.type = kwargs.get("type", None)
        self.osType = kwargs.get("osType", None)
        self.description = kwargs.get("description", None)
        self.alreadyExcluded = kwargs.get("alreadyExcluded", None)
        if attributes := kwargs.get("attributes"):
            self.attributes = []
            self.attributes += [CatalogExclusionAttributes(**a) for a in attributes]


class CatalogExclusionAttributes(object):
    def __init__(self, **kwargs):
        self.display = kwargs.get("display", None)
        self.displayAttribute = kwargs.get("displayAttribute", True)
        self.fieldId = kwargs.get("fieldId", None)
        self.section = kwargs.get("section", None)
        self.value = kwargs.get("value", None)
