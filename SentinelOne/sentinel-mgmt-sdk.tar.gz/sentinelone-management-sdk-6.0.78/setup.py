from setuptools import setup, find_packages

package_version = '6.0.78'

requires = [
    "requests>=2.20",
    "urllib3>=1.26.5,<2.0.0",
    "six>=1.13.0",
]

setup(
    name='sentinelone-management-sdk',
    version=package_version,
    packages=find_packages(exclude=["tests"]),
    license='SentinelOne - Corporate IP',
    install_requires=requires,
)
